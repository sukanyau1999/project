#!C:/python34/python
import cgi
import mysql.connector
print("Content-type: text/html")
print("")
cnx = mysql.connector.connect(user='root', password='',
                              host='localhost',
                              database='hospital');
print("""
<!DOCTYPE html>
<html lang="en">
  <head>
    
  <body style="padding-top:50px;">
 <div class="jumbotron"></div>
   <div class="container">
		<div class="card-body" style="background-color:#3498DB;color:#ffffff;">
		<a href="add2.html" class="btn btn-light">Go Back</a>
		Patient details
		</div>
	<div class="card-body"></div>
	<table class="table table-hover">
	<thead>
		<tr>
			<th>First name</th>
			<th>last name</th>
			<th>Email ID</th>
			<th>Contact</th>
			<th>Doctor Appointment</th>
		</tr>
	</thead>
	<tboby>
	""")
cursor=cnx.cursor()
cursor.execute("""
    SELECT * FROM appointment""")
for row in cursor:
	print("<tr>");
	print("<td>",row[0],"</td>")
	print("<td>",row[1],"</td>")
	print("<td>",row[2],"</td>")	
	print("<td>",row[3],"</td>")
	print("<td>",row[4],"</td>")
	print("<tr>");
print("</tbody></table>");

print("""

</div>
</div>
	
	
	
	
	
	
	<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

	
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <!--Sweet alert js-->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.1/sweetalert2.all.min.js"></script>
</body>
</html>
""")
