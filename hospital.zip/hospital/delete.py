#!C:/python34/python
import cgi
import mysql.connector
print("Content-type: text/html")
print("")


form=cgi.FieldStorage()

cn=form.getvalue("contact");


cnx = mysql.connector.connect(user='root', password='',
                              host='localhost',
                              database='hospital')
cursor=cnx.cursor()
cursor.execute("""
    delete from add_doc where contact=%s""", (cn,))
print("<script>alert('Doctor Delete Successfully')</script>")
cnx.commit()
cnx.close()
