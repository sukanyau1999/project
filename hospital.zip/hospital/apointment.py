#!C:/python34/python
import cgi
import mysql.connector
print("Content-type: text/html")
print("")


form=cgi.FieldStorage()

cn=form.getvalue("fname");

ct=form.getvalue("lname");

pn=form.getvalue("email");

pp=form.getvalue("contact");

pd=form.getvalue("doctor");

pi=form.getvalue("status");




cnx = mysql.connector.connect(user='root', password='',
                              host='localhost',
                              database='hospital')

cursor=cnx.cursor()
cursor.execute("""
    INSERT INTO appointment(fname,lname,email,contact,doctor,status) VALUES (%s, %s, %s, %s, %s, %s)""", (cn, ct, pn, pp, pd, pi))
print("<script>alert('Inserted')</script>")
cnx.commit()
cnx.close()
